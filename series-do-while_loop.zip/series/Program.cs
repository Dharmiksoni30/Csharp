﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace series
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter the number:");
           // int i = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1;
            int a = 2;
            int b = 3;

            while(i<n)
            {
                if(i<=3)
                {
                    Console.Write(i+" ");
                }
                else
                {
                    int temp = a * b;
                    if(temp>n)
                    {
                        break;
                    }
                    Console.Write(temp+" ");
                    a = b;
                    b = temp;
                }
                i++;
            }
            Console.Read();
        }
    }
}
