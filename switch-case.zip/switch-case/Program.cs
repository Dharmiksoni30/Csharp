﻿//switch-case
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set console color blue=1");
            Console.WriteLine("set console color red=2");
            Console.WriteLine("set console color yellow=3");
            Console.Write("enter the color code:");
            int n = Convert.ToInt32(Console.ReadLine());
            switch(n)
            {
                case 1: 
                    Console.BackgroundColor = ConsoleColor.DarkBlue;
                   Console.Clear();
                    break;
                case 2: 
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.Clear();
                    break;
                case 3: 
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.Clear();
                    break;
                default:
                    Console.Write("please enter right color code");
                    break;
            }
            Console.Read();
        }
    }
}
